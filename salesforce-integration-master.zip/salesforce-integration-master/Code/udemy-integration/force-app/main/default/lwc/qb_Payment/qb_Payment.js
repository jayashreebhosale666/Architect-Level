import { LightningElement } from 'lwc';

export default class Qb_Payment extends LightningElement {}