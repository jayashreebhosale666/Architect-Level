import { LightningElement } from 'lwc';

export default class Gg_Event extends LightningElement {}