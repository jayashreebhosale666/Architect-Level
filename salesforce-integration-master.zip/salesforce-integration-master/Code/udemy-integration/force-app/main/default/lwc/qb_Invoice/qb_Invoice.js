import { LightningElement } from 'lwc';

export default class Qb_Invoice extends LightningElement {}