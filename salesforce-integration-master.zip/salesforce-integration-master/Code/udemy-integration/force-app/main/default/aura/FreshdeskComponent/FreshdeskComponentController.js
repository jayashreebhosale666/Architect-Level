({
	doCreate : function(component, event, helper) {
		helper.onCreate(component, event, helper);
	}
})