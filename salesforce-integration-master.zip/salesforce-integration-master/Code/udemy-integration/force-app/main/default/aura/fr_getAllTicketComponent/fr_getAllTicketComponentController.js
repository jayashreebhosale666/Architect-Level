({
	doClick : function(component, event, helper) {
		helper.onClick(component, event, helper);
	}
})